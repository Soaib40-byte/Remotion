// Synthesizes a small, soft UI/motion-graphics SFX kit (16-bit mono WAV, 44.1kHz). No dependencies.
import { writeFileSync, mkdirSync } from "node:fs";
const SR = 44100, OUT = new URL("../public/sfx/", import.meta.url).pathname;
mkdirSync(OUT, { recursive: true });
let seed = 7; const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
const env = (t, a, d) => Math.min(1, t / a) * Math.exp(-t / d);
const lp = (x, k) => { let y = 0; return x.map((v) => (y += k * (v - y))); };
const hp = (x, k) => { const l = lp(x, k); return x.map((v, i) => v - l[i]); };
const bp = (x, lo, hi) => hp(lp(x, hi), lo);
function reverb(x, mix = 0.12) { // very short comb reverb
  const o = x.slice(); for (const [d, g] of [[0.011, 0.35], [0.017, 0.28], [0.023, 0.2]]) {
    const n = Math.floor(d * SR); for (let i = n; i < o.length; i++) o[i] += x[i - n] * g * mix * 3; } return o; }
function norm(x, peak) { const m = Math.max(...x.map(Math.abs)) || 1; return x.map((v) => (v / m) * peak); }
function fadeEnds(x, ms = 6) { const n = Math.floor(SR * ms / 1000); for (let i = 0; i < n; i++) { x[i] *= i / n; x[x.length - 1 - i] *= i / n; } return x; }
function wav(name, x) {
  const b = Buffer.alloc(44 + x.length * 2); b.write("RIFF", 0); b.writeUInt32LE(36 + x.length * 2, 4); b.write("WAVEfmt ", 8);
  b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22); b.writeUInt32LE(SR, 24); b.writeUInt32LE(SR * 2, 28);
  b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34); b.write("data", 36); b.writeUInt32LE(x.length * 2, 40);
  x.forEach((v, i) => b.writeInt16LE(Math.round(Math.max(-1, Math.min(1, v)) * 32767), 44 + i * 2));
  writeFileSync(OUT + name + ".wav", b);
}
const gen = (dur, f) => Array.from({ length: Math.floor(dur * SR) }, (_, i) => f(i / SR, i));
// pop: sine with fast downward pitch + short envelope
{ let ph = 0; const x = gen(0.22, (t) => { const f = 90 + 520 * Math.exp(-t / 0.028); ph += 2 * Math.PI * f / SR; return Math.sin(ph) * env(t, 0.004, 0.05); });
  wav("pop", fadeEnds(norm(reverb(lp(x, 0.35)), 0.8))); }
// click: high-passed tiny noise burst, softened
{ const n = gen(0.09, (t) => rnd() * env(t, 0.001, 0.012)); wav("click", norm(fadeEnds(lp(hp(n, 0.25), 0.55), 1), 0.8)); }
// whoosh (long, soft): band-passed noise sweep, fade in/out
{ const d = 0.75; let x = gen(d, () => rnd()); const sw = x.map((v, i) => v); const out = new Array(x.length).fill(0);
  const chunks = 24, cl = Math.floor(x.length / chunks);
  for (let c = 0; c < chunks; c++) { const p = c / (chunks - 1), hi = 0.05 + 0.5 * Math.sin(Math.PI * p) ** 1.5 + 0.03; const seg = bp(sw.slice(c * cl, (c + 1) * cl), 0.02, hi);
    seg.forEach((v, i) => (out[c * cl + i] = v)); }
  const y = out.map((v, i) => v * Math.sin(Math.PI * (i / out.length)) ** 2); wav("whoosh", fadeEnds(norm(reverb(lp(y, 0.5)), 0.8))); }
// swipe (short transition whoosh)
{ const d = 0.42; const raw = gen(d, () => rnd()); const out = new Array(raw.length).fill(0); const chunks = 14, cl = Math.floor(raw.length / chunks);
  for (let c = 0; c < chunks; c++) { const p = c / (chunks - 1), hi = 0.08 + 0.45 * Math.sin(Math.PI * p); const seg = bp(raw.slice(c * cl, (c + 1) * cl), 0.03, hi); seg.forEach((v, i) => (out[c * cl + i] = v)); }
  const y = out.map((v, i) => v * Math.sin(Math.PI * (i / out.length)) ** 1.6); wav("swipe", fadeEnds(norm(lp(y, 0.45), 0.8))); }
// chime: soft pluck with gentle overtones
{ const f0 = 784; const x = gen(0.5, (t) => (Math.sin(2 * Math.PI * f0 * t) * 1 + Math.sin(2 * Math.PI * f0 * 2.01 * t) * 0.3 * Math.exp(-t / 0.08) + Math.sin(2 * Math.PI * f0 * 3.02 * t) * 0.12 * Math.exp(-t / 0.05)) * env(t, 0.005, 0.12));
  wav("chime", fadeEnds(norm(reverb(lp(x, 0.4), 0.2), 0.8), 12)); }
// thud: very soft low sine thump (hook / key message only)
{ let ph = 0; const x = gen(0.4, (t) => { const f = 48 + 60 * Math.exp(-t / 0.05); ph += 2 * Math.PI * f / SR; return Math.sin(ph) * env(t, 0.006, 0.11); });
  wav("thud", fadeEnds(norm(lp(x, 0.3), 0.8))); }
console.log("sfx ok");
