# লালবাগ কেল্লা — মোশন গ্রাফিক্স ডকুমেন্টারি (Remotion)

1. `npm install`
2. `npx remotion studio`  → কম্পোজিশন **Main** (1920×1080, 30fps, ৭:৫৩)
3. `npx remotion render src/index.ts Main out/video.mp4`

- সময়: সবকিছু `public/lalbagh.srt` থেকে (cue নম্বর → `src/scenes.ts`)।
- ভয়েসওভার: `public/voiceover.mp3` (Studio প্রিভিউতে বাজে; রেন্ডারে ডিফল্টে বন্ধ — `src/theme.ts` → `flags`)।
- রং/ফন্ট/ইজিং/স্প্রিং/SFX ভলিউম: `src/theme.ts`।
- SFX পুনরায় বানাতে: `node scripts/make-sfx.mjs`
- ফন্ট: GNU FreeSerif/FreeSans Bold (`public/fonts`)। Hind Siliguri/Noto Serif Bengali চাইলে TTF `public/fonts`-এ রেখে `src/Root.tsx`-এর `FONTS` বদলান।
