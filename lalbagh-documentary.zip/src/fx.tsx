import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import { alpha, theme } from "./theme";
import type { Cue } from "./srt";

export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.accent, mixBlendMode: "soft-light", opacity: 0.2 }} />
    <AbsoluteFill style={{ background: `linear-gradient(180deg, ${alpha(theme.colors.black, 0.12)}, transparent 28%, transparent 72%, ${alpha(theme.colors.black, 0.22)})` }} />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px", backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.06, mixBlendMode: "overlay" }} />;
};

export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background: `radial-gradient(ellipse at center, transparent 55%, ${alpha(theme.colors.black, 0.45)} 100%)` }} />
);

/** optional word-by-word captions straight from the SRT (flags.WORD_CAPTIONS) */
export const WordCaptions: React.FC<{ cues: Cue[] }> = ({ cues }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = f / fps;
  const cur = cues.find((c) => t >= c.start && t < c.end + 0.08);
  if (!cur) return null;
  return <div style={{ position: "absolute", left: 0, right: 0, bottom: 70, textAlign: "center", fontFamily: theme.fonts.body, fontWeight: 700, fontSize: 64, color: theme.colors.text, textShadow: `0 0 8px ${theme.colors.black}, 0 3px 18px ${theme.colors.black}`, zIndex: 50 }}>{cur.text}</div>;
};
