import React, { useEffect, useState } from "react";
import { Composition, continueRender, delayRender, staticFile } from "remotion";
import { Main, MainProps } from "./Main";
import { parseSrt } from "./srt";
import { VIDEO, sec, theme } from "./theme";

const FONTS: [string, string][] = [["LalbaghSerif", "fonts/FreeSerifBold.ttf"], ["LalbaghSans", "fonts/FreeSansBold.ttf"]];

const useFonts = () => {
  const [h] = useState(() => delayRender("fonts"));
  useEffect(() => {
    Promise.all(FONTS.map(async ([name, file]) => { const f = new FontFace(name, `url(${staticFile(file)})`, { weight: "700" }); await f.load(); document.fonts.add(f); }))
      .catch(() => {}).finally(() => continueRender(h));
  }, [h]);
};

export const Root: React.FC = () => {
  useFonts();
  return (
    <Composition
      id="Main"
      component={Main}
      width={VIDEO.width}
      height={VIDEO.height}
      fps={VIDEO.fps}
      durationInFrames={30}
      defaultProps={{ cues: [] } as MainProps}
      calculateMetadata={async () => {
        const cues = parseSrt(await (await fetch(staticFile("lalbagh.srt"))).text());
        return { durationInFrames: sec(cues[cues.length - 1].end + theme.time.tail, VIDEO.fps), props: { cues } };
      }}
    />
  );
};
