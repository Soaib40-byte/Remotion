import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { flags } from "./theme";

/** Plays public/voiceover.mp3 for sync-checking. Silently skipped if the file is missing.
 *  In renders it stays off unless flags.VOICEOVER_IN_RENDER = true. */
export const PreviewAudio: React.FC = () => {
  const [ok, setOk] = useState(false);
  const rendering = getRemotionEnvironment().isRendering;
  const wanted = rendering ? flags.VOICEOVER_IN_RENDER : flags.PREVIEW_VOICEOVER;
  useEffect(() => {
    if (!wanted) return;
    const h = delayRender("voiceover-check");
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => setOk(r.ok && !(r.headers.get("content-type") || "").includes("html")))
      .catch(() => setOk(false))
      .finally(() => continueRender(h));
  }, [wanted]);
  if (!wanted || !ok) return null;
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};
