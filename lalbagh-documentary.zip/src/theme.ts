// theme.ts — single source of truth: colors, fonts, easing, spring presets, timing, SFX table, flags.
import { Easing } from "remotion";

export const VIDEO = { width: 1920, height: 1080, fps: 30 } as const;

export const flags = {
  VOICEOVER_IN_RENDER: false, // true => public/voiceover.mp3 is also baked into the rendered MP4
  PREVIEW_VOICEOVER: true, // plays public/voiceover.mp3 inside Remotion Studio (skipped silently if missing)
  WORD_CAPTIONS: false, // true => word-by-word subtitle from the SRT at the bottom
};

export const theme = {
  colors: {
    bg: "#0B1A1F", bgAlt: "#102A30", hero: "#D4AF37", heroLight: "#F4DE8E", accent: "#1F7A7A",
    accentSoft: "#2FA3A0", text: "#F3EAD3", textDim: "#B9B29C", ink: "#2A1B12", inkAccent: "#7A2E1D",
    glow: "rgba(212,175,55,0.38)", shadow: "rgba(0,0,0,0.6)", black: "#000000",
  },
  fonts: {
    display: '"LalbaghSerif", "FreeSerif", serif',
    body: '"LalbaghSans", "FreeSans", sans-serif',
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  // seconds (converted with fps — no magic frame numbers)
  time: { lead: 0.17, sceneLead: 0.27, trans: 0.27, tail: 0.7, wordGap: 0.13, exit: 0.3 },
  sfx: {
    whoosh: { file: "sfx/whoosh.wav", vol: 0.26, len: 0.8 },
    swipe: { file: "sfx/swipe.wav", vol: 0.3, len: 0.5 },
    pop: { file: "sfx/pop.wav", vol: 0.3, len: 0.3 },
    click: { file: "sfx/click.wav", vol: 0.34, len: 0.2 },
    chime: { file: "sfx/chime.wav", vol: 0.26, len: 0.6 },
    thud: { file: "sfx/thud.wav", vol: 0.3, len: 0.5 },
  },
} as const;

export type SfxName = keyof typeof theme.sfx;
export type ColorName = keyof typeof theme.colors;
export const sec = (s: number, fps: number) => Math.round(s * fps);
export const toBn = (n: number) => String(Math.round(n)).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[+d]);
export const alpha = (hex: string, a: number) => hex + Math.round(a * 255).toString(16).padStart(2, "0");
