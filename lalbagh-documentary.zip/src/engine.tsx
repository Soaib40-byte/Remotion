import React, { createContext, useContext } from "react";
import { AbsoluteFill, Audio, Img, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { alpha, sec, theme, toBn } from "./theme";
import type { Cue } from "./srt";
import type { CardItem, CtItem, ElItem, HaloItem, Item, KB, SceneDef, SpotItem, TlItem, TxItem } from "./types";

type Ctx = { cues: Cue[]; sceneStart: number; dur: number; idx: number };
export const SceneCtx = createContext<Ctx>({ cues: [], sceneStart: 0, dur: 1, idx: 0 });
const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** frame (relative to scene start) at which a cue's visual should land = cue start − lead (SRT is the only clock) */
const cueFrame = (c: Ctx, cue: number, fps: number) => Math.max(0, Math.round(c.cues[cue - 1].start * fps) - sec(theme.time.lead, fps) - c.sceneStart);

// ───────────────────────── SFX ─────────────────────────
const Sfx: React.FC<{ name: keyof typeof theme.sfx; at: number; seed: number }> = ({ name, at, seed }) => {
  const { fps } = useVideoConfig();
  const s = theme.sfx[name];
  const rate = 0.94 + (seed % 7) * 0.02; // slight pitch variation
  return (
    <Sequence from={Math.max(0, at - 2)} durationInFrames={sec(s.len, fps)} layout="none">
      <Audio src={staticFile(s.file)} volume={s.vol} playbackRate={rate} />
    </Sequence>
  );
};

// ───────────────────────── Backgrounds ─────────────────────────
const Dust: React.FC<{ seed: number }> = ({ seed }) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ mixBlendMode: "screen", pointerEvents: "none" }}>
      {Array.from({ length: 16 }).map((_, i) => {
        const r = (n: number) => ((Math.sin((i + 1) * 12.9898 + seed * 4.1 + n * 78.233) * 43758.5453) % 1 + 1) % 1;
        const x = r(1) * 1920 + Math.sin(f / (60 + r(2) * 50) + i) * 40;
        const y = ((r(3) * 1080 - f * (0.25 + r(4) * 0.5)) % 1080 + 1080) % 1080;
        const s = 3 + r(5) * 5;
        return <div key={i} style={{ position: "absolute", left: x, top: y, width: s, height: s, borderRadius: "50%", background: theme.colors.hero, opacity: 0.12 + r(6) * 0.25, filter: "blur(1px)" }} />;
      })}
    </AbsoluteFill>
  );
};

const Mesh: React.FC<{ seed: number }> = ({ seed }) => {
  const f = useCurrentFrame();
  const d1 = Math.sin(f / 55 + seed) * 50, d2 = Math.cos(f / 70 + seed) * 40;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div style={{ position: "absolute", width: 1200, height: 1200, borderRadius: "50%", top: -450, left: -300 + d1, filter: "blur(60px)", background: `radial-gradient(circle, ${alpha(theme.colors.accent, 0.3)}, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 900, height: 900, borderRadius: "50%", bottom: -400, right: -250 - d2, filter: "blur(70px)", background: `radial-gradient(circle, ${alpha(theme.colors.hero, 0.14)}, transparent 65%)` }} />
    </AbsoluteFill>
  );
};

const kbTransform = (kb: KB, t: number) => {
  const e = theme.ease.inOut(t);
  switch (kb) {
    case "in": return `scale(${1 + 0.12 * e})`;
    case "out": return `scale(${1.12 - 0.12 * e})`;
    case "left": return `scale(1.1) translateX(${3 - 6 * e}%)`;
    case "right": return `scale(1.1) translateX(${-3 + 6 * e}%)`;
    case "up": return `scale(1.1) translateY(${3 - 6 * e}%)`;
    default: return `scale(1.1) translateY(${-3 + 6 * e}%)`;
  }
};

const Photo: React.FC<{ src: string; kb: KB; bright: number; style?: React.CSSProperties; opacity?: number; t0?: number }> = ({ src, kb, bright, style, opacity = 1, t0 = 0 }) => {
  const f = useCurrentFrame();
  const { dur } = useContext(SceneCtx);
  const t = Math.min(1, Math.max(0, (f - t0) / Math.max(1, dur)));
  return (
    <div style={{ position: "absolute", overflow: "hidden", opacity, ...style }}>
      <Img src={staticFile(src)} style={{ width: "100%", height: "100%", objectFit: "cover", transform: kbTransform(kb, t), filter: `brightness(${bright}) saturate(1.05)` }} />
    </div>
  );
};

const scrimCss = (s: string) => {
  const c = theme.colors.bg;
  if (s === "left") return `linear-gradient(90deg, ${alpha(c, 0.82)}, ${alpha(c, 0.25)} 70%)`;
  if (s === "right") return `linear-gradient(270deg, ${alpha(c, 0.82)}, ${alpha(c, 0.25)} 70%)`;
  if (s === "center") return `radial-gradient(ellipse at center, ${alpha(c, 0.62)}, ${alpha(c, 0.2)} 75%)`;
  return `linear-gradient(180deg, ${alpha(c, 0.5)}, ${alpha(c, 0.12)} 38%, ${alpha(c, 0.7)})`;
};

const Background: React.FC<{ def: SceneDef; seed: number }> = ({ def, seed }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const c = useContext(SceneCtx);
  const mode = def.mode ?? "full";
  const kb = def.kb ?? "in";
  const bright = def.bright ?? 0.6;
  const imgs = Array.isArray(def.img) ? def.img : def.img ? [def.img] : [];
  const cutF = def.cutAt ? cueFrame(c, def.cutAt, fps) : 0;
  const fade = interpolate(f, [cutF, cutF + sec(0.3, fps)], [0, 1], clamp);
  if (mode === "parch") {
    const s = 1 + 0.03 * theme.ease.inOut(Math.min(1, f / Math.max(1, c.dur)));
    return (<AbsoluteFill style={{ background: theme.colors.bg }}><Img src={staticFile("elements/el_parchment_panel.png")} style={{ width: "100%", height: "100%", objectFit: "cover", transform: `scale(${s})` }} /></AbsoluteFill>);
  }
  return (
    <AbsoluteFill>
      <Mesh seed={seed} />
      {mode === "card" && def.card ? (
        <>
          {imgs[0] && <Photo src={imgs[0]} kb={kb} bright={0.28} style={{ inset: 0, filter: "blur(28px)" }} />}
          <div style={{ position: "absolute", left: def.card.x - def.card.w / 2, top: def.card.y - def.card.h / 2 + Math.sin(f / 40) * 4, width: def.card.w, height: def.card.h, borderRadius: 28, overflow: "hidden", border: `1px solid ${alpha(theme.colors.hero, 0.45)}`, boxShadow: `0 40px 80px -20px ${theme.colors.shadow}, 0 0 60px ${alpha(theme.colors.hero, 0.12)}` }}>
            {imgs.map((s, i) => <Photo key={s} src={s} kb={i ? "out" : kb} bright={0.9} style={{ inset: 0 }} opacity={i ? fade : 1} />)}
          </div>
        </>
      ) : (
        <>
          {imgs.map((s, i) => <Photo key={s} src={s} kb={i ? "out" : kb} bright={bright} style={{ inset: 0 }} opacity={i ? fade : 1} t0={i ? cutF : 0} />)}
          <AbsoluteFill style={{ background: scrimCss(def.scrim ?? "bottom") }} />
        </>
      )}
      <Dust seed={seed} />
      {mode === "teal" && <Img src={staticFile("elements/el_endcard_bg.png")} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.86 }} />}
    </AbsoluteFill>
  );
};

// ───────────────────────── Item helpers ─────────────────────────
const exitProg = (f: number, ex: number | undefined, fps: number) => (ex === undefined ? 0 : interpolate(f - ex, [0, sec(theme.time.exit, fps)], [0, 1], { ...clamp, easing: theme.ease.in }));

const pos = (x: number, y: number, extra: React.CSSProperties = {}): React.CSSProperties => ({ position: "absolute", left: x, top: y, transform: "translate(-50%, -50%)", ...extra });

const useItem = (it: { at: number; d?: number; until?: number }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const c = useContext(SceneCtx);
  const f0 = cueFrame(c, it.at, fps) + sec(it.d ?? 0, fps);
  const ex = it.until ? cueFrame(c, it.until, fps) : undefined;
  return { f, fps, f0, lf: f - f0, ex, exp: exitProg(f, ex, fps), c };
};

const animStyle = (a: string, lf: number, fps: number): { opacity: number; transform: string; clip?: string } => {
  const sp = (cfg: typeof theme.spring.snappy) => spring({ frame: lf, fps, config: cfg });
  const ease = (n: number) => interpolate(lf, [0, sec(n, fps)], [0, 1], { ...clamp, easing: theme.ease.out });
  switch (a) {
    case "pop": { const p = sp(theme.spring.bouncy); return { opacity: Math.min(1, p * 2), transform: `translateY(${(1 - p) * 24}px) scale(${0.6 + 0.4 * p})` }; }
    case "stamp": { const p = sp(theme.spring.snappy); return { opacity: Math.min(1, p * 2.5), transform: `scale(${1.7 - 0.7 * p}) rotate(${(1 - p) * -8}deg)` }; }
    case "drop": { const p = sp(theme.spring.bouncy); return { opacity: Math.min(1, p * 3), transform: `translateY(${(1 - p) * -220}px)` }; }
    case "zoom": { const p = ease(1.1); return { opacity: p, transform: `scale(${1.06 - 0.06 * p})` }; }
    case "drawX": { const p = ease(0.9); return { opacity: 1, transform: "none", clip: `inset(0 ${(1 - p) * 100}% 0 0)` }; }
    case "drawY": { const p = ease(0.9); return { opacity: 1, transform: "none", clip: `inset(0 0 ${(1 - p) * 100}% 0)` }; }
    case "iris": { const p = ease(0.9); return { opacity: Math.min(1, p * 2), transform: `scale(${0.9 + 0.1 * p})`, clip: `circle(${p * 78}% at 50% 50%)` }; }
    case "slideL": { const p = ease(0.8); return { opacity: p, transform: `translateX(${(1 - p) * -360}px)` }; }
    case "slideR": { const p = ease(0.8); return { opacity: p, transform: `translateX(${(1 - p) * 360}px)` }; }
    default: { const p = sp(theme.spring.smooth); return { opacity: p, transform: `translateY(${(1 - p) * 46}px) scale(${0.94 + 0.06 * p})` }; }
  }
};

// ───────────────────────── Items ─────────────────────────
const El: React.FC<{ it: ElItem; seed: number }> = ({ it, seed }) => {
  const { f, fps, lf, exp } = useItem(it);
  if (lf < 0 || exp >= 1) return null;
  const a = animStyle(it.anim ?? "rise", lf, fps);
  const breathe = it.breathe !== false && lf > sec(1, fps) && !["drawX", "drawY"].includes(it.anim ?? "");
  const sc = breathe ? 1 + Math.sin((f + seed * 7) / 24) * 0.01 : 1;
  const fy = breathe ? Math.sin((f + seed * 5) / 32) * 3 : 0;
  return (
    <div style={pos(it.x, it.y, { width: it.w, mixBlendMode: it.blend === "normal" ? "normal" : "screen", zIndex: it.z ?? 2, opacity: it.op ?? 1 })}>
      <div style={{ clipPath: a.clip, opacity: a.opacity * (1 - exp), transform: `${a.transform} translateY(${fy - exp * 24}px) scale(${sc}) rotate(${it.rot ?? 0}deg)`, position: "relative" }}>
        {it.glow && <div style={{ position: "absolute", inset: "-14%", background: `radial-gradient(circle, ${theme.colors.glow} 0%, transparent 62%)`, opacity: 0.8 }} />}
        <Img src={staticFile(it.src)} style={{ width: "100%", display: "block", position: "relative" }} />
      </div>
    </div>
  );
};

const Halo: React.FC<{ it: HaloItem }> = ({ it }) => {
  const { fps, lf, exp } = useItem(it);
  if (lf < 0) return null;
  const p = interpolate(lf, [0, sec(0.6, fps)], [0, 1], { ...clamp, easing: theme.ease.out });
  return <div style={pos(it.x, it.y, { width: it.r * 2, height: it.r * 2, borderRadius: "50%", background: `radial-gradient(circle, ${alpha(theme.colors.bg, 0.8)} 0%, ${alpha(theme.colors.bg, 0.55)} 50%, transparent 72%)`, opacity: p * (1 - exp), zIndex: 1 })} />;
};

const Card: React.FC<{ it: CardItem }> = ({ it }) => {
  const { fps, lf, exp } = useItem(it);
  if (lf < 0 || exp >= 1) return null;
  const a = animStyle("rise", lf, fps);
  return <div style={pos(it.x, it.y, { width: it.w, height: it.h, borderRadius: 26, background: `linear-gradient(160deg, ${alpha(theme.colors.bgAlt, 0.72)}, ${alpha(theme.colors.bg, 0.6)})`, border: `1px solid ${alpha(theme.colors.hero, 0.32)}`, boxShadow: `0 30px 60px -20px ${theme.colors.shadow}`, backdropFilter: "blur(14px)", opacity: a.opacity * (1 - exp), transform: `translate(-50%,-50%) ${a.transform}`, zIndex: 1 })} />;
};

const wordStyle = (emphasized: boolean): React.CSSProperties =>
  emphasized ? { background: `linear-gradient(90deg, ${theme.colors.hero}, ${theme.colors.heroLight})`, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", WebkitTextFillColor: "transparent", filter: `drop-shadow(0 0 18px ${theme.colors.glow})` } : {};

const Tx: React.FC<{ it: TxItem }> = ({ it }) => {
  const { f, fps, lf, exp } = useItem(it);
  if (lf < 0 || exp >= 1) return null;
  const size = it.size ?? 72, align = it.align ?? "center", anim = it.anim ?? "words";
  const per = it.per ?? sec(theme.time.wordGap, fps) ;
  const lines = it.text.split("\n");
  let wi = 0;
  const jc = align === "left" ? "flex-start" : align === "right" ? "flex-end" : "center";
  const color = theme.colors[it.color ?? "text"];
  return (
    <div style={pos(it.x, it.y, { width: it.w ?? 1500, textAlign: align, fontFamily: it.font === "body" ? theme.fonts.body : theme.fonts.display, fontSize: size, lineHeight: 1.38, letterSpacing: 0, color, fontWeight: 700, textShadow: it.shadow === false ? undefined : `0 4px 26px ${theme.colors.shadow}`, opacity: 1 - exp, transform: `translate(-50%,-50%) translateY(${-exp * 20}px)`, zIndex: it.z ?? 3 })}>
      {lines.map((line, li) => {
        const words = line.split(" ").filter(Boolean);
        const lineEl = (
          <div key={li} style={{ display: "flex", flexWrap: "wrap", justifyContent: jc, columnGap: Math.round(size * 0.26) }}>
            {words.map((w, k) => {
              const gi = wi++;
              const em = it.emph?.includes(gi) ?? false;
              let st: React.CSSProperties = {};
              if (anim === "words") {
                const p = spring({ frame: lf - gi * per, fps, config: theme.spring.snappy });
                st = { opacity: p, transform: `translateY(${(1 - p) * 34}px) scale(${0.96 + 0.04 * p})` };
              } else if (anim === "type") {
                const vis = lf >= gi * sec(0.26, fps);
                st = { opacity: vis ? 1 : 0 };
              }
              return <span key={k} style={{ display: "inline-block", whiteSpace: "nowrap", ...st, ...wordStyle(em) }}>{w}</span>;
            })}
          </div>
        );
        if (anim === "mask") {
          const p = interpolate(lf - li * 6, [0, sec(0.7, fps)], [0, 1], { ...clamp, easing: theme.ease.out });
          return <div key={li} style={{ overflow: "hidden", padding: "0.1em 0.2em" }}><div style={{ transform: `translateY(${(1 - p) * 110}%)` }}>{lineEl}</div></div>;
        }
        return lineEl;
      })}
      {anim === "type" && Math.floor(f / 14) % 2 === 0 && <span style={{ color: theme.colors.hero }}>|</span>}
    </div>
  ) as React.ReactElement | null;
};

// wrapper for non-words whole-block anims (pop / rise)
const TxBlock: React.FC<{ it: TxItem }> = ({ it }) => {
  const { fps, lf } = useItem(it);
  if (it.anim === "pop" || it.anim === "rise") {
    const a = animStyle(it.anim, lf, fps);
    return <div style={{ position: "absolute", inset: 0, opacity: a.opacity, transform: a.transform, transformOrigin: `${it.x}px ${it.y}px`, zIndex: 3 }}><Tx it={{ ...it, anim: "mask", per: 0 }} /></div>;
  }
  return <Tx it={it} />;
};

const Ct: React.FC<{ it: CtItem }> = ({ it }) => {
  const { fps, lf, exp } = useItem(it);
  if (lf < 0 || exp >= 1) return null;
  const p = interpolate(lf, [0, sec(it.dur ?? 1.5, fps)], [0, 1], { ...clamp, easing: theme.ease.out });
  const a = animStyle("rise", lf, fps);
  return <div style={pos(it.x, it.y, { fontFamily: theme.fonts.display, fontWeight: 700, fontSize: it.size ?? 150, color: theme.colors[it.color ?? "hero"], lineHeight: 1.3, whiteSpace: "nowrap", textShadow: `0 0 40px ${theme.colors.glow}`, opacity: a.opacity * (1 - exp), zIndex: 3, transform: `translate(-50%,-50%) ${a.transform}` })}>{toBn(it.to * p)}{it.suffix ?? ""}</div>;
};

const Tl: React.FC<{ it: TlItem }> = ({ it }) => {
  const { fps, f, lf, c } = useItem(it);
  if (lf < 0) return null;
  const n = it.nodes.length;
  const xs = it.nodes.map((_, i) => (n === 1 ? 0 : (i / (n - 1)) * it.w));
  const times = it.nodes.map((nd) => cueFrame(c, nd.at, fps) + sec(nd.d ?? 0, fps));
  const lit = times.filter((t) => f >= t).length;
  const lineP = lit <= 1 ? 0 : interpolate(f, [times[lit - 2], times[lit - 1]], [xs[lit - 2], xs[lit - 1]], { ...clamp, easing: theme.ease.inOut });
  return (
    <div style={{ position: "absolute", left: it.x - it.w / 2, top: it.y, width: it.w, height: 0, zIndex: 3 }}>
      <div style={{ position: "absolute", left: 0, top: -2, width: it.w, height: 4, borderRadius: 4, background: theme.colors.textDim, opacity: 0.25 }} />
      <div style={{ position: "absolute", left: 0, top: -2, width: lineP, height: 4, borderRadius: 4, background: theme.colors.hero, boxShadow: `0 0 18px ${theme.colors.glow}` }} />
      {it.nodes.map((nd, i) => {
        const p = spring({ frame: f - times[i], fps, config: theme.spring.bouncy });
        const on = f >= times[i];
        return (
          <div key={i} style={{ position: "absolute", left: xs[i], top: 0, width: 0, height: 0 }}>
            <div style={{ position: "absolute", left: -20, top: -20, width: 40, height: 40, borderRadius: "50%", border: `4px solid ${on ? theme.colors.hero : theme.colors.textDim}`, background: on ? theme.colors.hero : theme.colors.bg, transform: `scale(${on ? 0.5 + 0.5 * p : 1})`, boxShadow: on ? `0 0 28px ${theme.colors.glow}` : undefined }} />
            <div style={{ position: "absolute", left: -200, top: -150, width: 400, textAlign: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 84, lineHeight: 1.3, color: theme.colors.hero, opacity: Math.min(1, p) , transform: `translateY(${(1 - Math.min(1, p)) * 24}px)`, textShadow: `0 4px 24px ${theme.colors.shadow}` }}>{nd.label}</div>
            <div style={{ position: "absolute", left: -200, top: 44, width: 400, textAlign: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 44, lineHeight: 1.35, color: theme.colors.text, opacity: Math.min(1, p), textShadow: `0 3px 20px ${theme.colors.shadow}` }}>{nd.sub}</div>
          </div>
        );
      })}
    </div>
  );
};

const Spot: React.FC<{ it: SpotItem }> = ({ it }) => {
  const { fps, f, lf } = useItem(it);
  if (lf < 0) return null;
  const a = animStyle("iris", lf, fps);
  const h = it.w; // square asset
  const mx = 50 + Math.sin(f / 26) * 28, my = 50 + Math.cos(f / 19) * 26;
  const mask = `radial-gradient(circle at ${mx}% ${my}%, #000 0, #000 ${h * 0.07}px, transparent ${h * 0.22}px)`;
  return (
    <div style={pos(it.x, it.y, { width: it.w, height: h, mixBlendMode: "screen", zIndex: 2 })}>
      <div style={{ opacity: a.opacity, transform: a.transform, clipPath: a.clip }}>
        <Img src={staticFile(it.src)} style={{ width: "100%", opacity: 0.28, display: "block" }} />
        <Img src={staticFile(it.src)} style={{ position: "absolute", inset: 0, width: "100%", WebkitMaskImage: mask, maskImage: mask }} />
      </div>
    </div>
  );
};

export const ItemView: React.FC<{ it: Item; i: number; seed: number }> = ({ it, i, seed }) => {
  const { fps } = useVideoConfig();
  const c = useContext(SceneCtx);
  const sfxAt = it.sfx ? cueFrame(c, it.at, fps) + sec(it.d ?? 0, fps) : 0;
  const body = (() => {
    switch (it.k) {
      case "el": return <El it={it} seed={seed + i} />;
      case "tx": return <TxBlock it={it} />;
      case "ct": return <Ct it={it} />;
      case "card": return <Card it={it} />;
      case "halo": return <Halo it={it} />;
      case "tl": return <Tl it={it} />;
      default: return <Spot it={it} />;
    }
  })();
  return <>{body}{it.sfx && <Sfx name={it.sfx} at={sfxAt} seed={seed * 3 + i} />}</>;
};

// ───────────────────────── Scene ─────────────────────────
export const SceneView: React.FC<{ def: SceneDef; index: number; start: number; dur: number; cues: Cue[] }> = ({ def, index, start, dur, cues }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const T = sec(theme.time.trans, fps);
  const pIn = index === 0 ? interpolate(f, [0, sec(0.5, fps)], [0, 1], { ...clamp, easing: theme.ease.out }) : interpolate(f, [0, T], [0, 1], { ...clamp, easing: theme.ease.out });
  const pOut = interpolate(f, [dur, dur + T], [0, 1], { ...clamp, easing: theme.ease.in });
  const kind = index % 4;
  let clip: string | undefined;
  if (index > 0 && pIn < 1) {
    if (kind === 0) clip = `inset(0 ${(1 - pIn) * 100}% 0 0)`;
    else if (kind === 1) clip = `inset(${(1 - pIn) * 100}% 0 0 0)`;
    else if (kind === 2) clip = `circle(${pIn * 80}% at 50% 50%)`;
    else { const x = pIn * 125; clip = `polygon(0 0, ${x}% 0, ${x - 25}% 100%, 0 100%)`; }
  }
  const edge = index > 0 && pIn < 1 && kind < 2;
  const ctx: Ctx = { cues, sceneStart: start, dur, idx: index };
  return (
    <AbsoluteFill style={{ transform: `scale(${1 - 0.04 * pOut})`, filter: pOut > 0 ? `brightness(${1 - 0.5 * pOut})` : undefined }}>
      <SceneCtx.Provider value={ctx}>
        <AbsoluteFill style={{ clipPath: clip, opacity: index === 0 ? pIn : 1 }}>
          <AbsoluteFill style={{ transform: `scale(${1 + 0.05 * (1 - pIn)})` }}>
            <Background def={def} seed={index} />
            {def.items.map((it, i) => <ItemView key={i} it={it} i={i} seed={index} />)}
          </AbsoluteFill>
        </AbsoluteFill>
        {edge && <div style={kind === 0 ? { position: "absolute", top: 0, bottom: 0, left: `${pIn * 100}%`, width: 4, background: theme.colors.hero, boxShadow: `0 0 30px ${theme.colors.glow}` } : { position: "absolute", left: 0, right: 0, top: `${(1 - pIn) * 100}%`, height: 4, background: theme.colors.hero, boxShadow: `0 0 30px ${theme.colors.glow}` }} />}
        {index > 0 && <Sfx name="swipe" at={0} seed={index} />}
      </SceneCtx.Provider>
    </AbsoluteFill>
  );
};
