// scenes.ts — 46 scenes. `from` / `at` are SRT cue numbers (1-based). All timing is derived from lalbagh.srt.
import type { CardItem, CtItem, ElItem, HaloItem, SceneDef, SpotItem, TlItem, TxItem } from "./types";

type O<T> = Omit<T, "k" | "src" | "text" | "to">;
const E = (n: string, o: O<ElItem>): ElItem => ({ k: "el", src: `elements/el_${n}.png`, ...o });
const T = (text: string, o: O<TxItem>): TxItem => ({ k: "tx", text, ...o });
const C = (to: number, o: O<CtItem>): CtItem => ({ k: "ct", to, ...o });
const CARD = (o: O<CardItem>): CardItem => ({ k: "card", ...o });
const HALO = (o: O<HaloItem>): HaloItem => ({ k: "halo", ...o });
const SPOT = (n: string, o: O<SpotItem>): SpotItem => ({ k: "spot", src: `elements/el_${n}.png`, ...o });
const TL = (o: Omit<TlItem, "k">): TlItem => ({ k: "tl", ...o });
const I = (n: string) => `images/${n}.jpg`;
const CX = 960, CY = 540;

export const SCENES: SceneDef[] = [
  // 1 — hook: title in ornate frame (Kinetic / Hero)
  { id: "s01-hook", from: 1, img: I("img01_gate"), kb: "in", scrim: "center", items: [
    E("frame_ornate", { x: CX, y: CY, w: 1840, at: 1, anim: "zoom", sfx: "thud" }),
    T("লালবাগ কেল্লা\nকেন আজও অসমাপ্ত?", { x: CX, y: 470, size: 128, at: 1, d: 0.45, sfx: "whoosh", emph: [4] }),
    E("divider", { x: CX, y: 700, w: 780, at: 1, d: 1.7, anim: "drawX" }),
  ] },
  // 2 — 340 years counter
  { id: "s02-counter", from: 12, img: I("img02_unfinished_wall"), kb: "right", items: [
    E("date_plaque_a", { x: CX, y: 400, w: 1000, at: 12, anim: "pop", sfx: "chime" }),
    C(340, { x: CX, y: 400, size: 150, at: 12, dur: 1.4, suffix: " বছর" }),
    T("অসমাপ্ত", { x: CX, y: 640, size: 120, at: 20, anim: "mask", emph: [0] }),
    T("হঠাৎ থেমে গেছে, মাঝপথে", { x: CX, y: 880, size: 58, at: 23, anim: "mask", color: "textDim" }),
  ] },
  // 3 — trio of causes
  { id: "s03-trio", from: 37, img: I("img04_tomb_interior"), kb: "in", scrim: "center", items: [
    T("থেমে যাওয়ার পেছনে", { x: CX, y: 160, size: 70, at: 37 }),
    HALO({ x: 400, y: 460, r: 300, at: 43 }), E("icon_tomb", { x: 400, y: 440, w: 330, at: 43, anim: "pop", sfx: "pop" }), T("তরুণীর মৃত্যু", { x: 400, y: 740, size: 66, at: 43, anim: "mask" }),
    HALO({ x: CX, y: 460, r: 300, at: 46 }), E("icon_lantern", { x: CX, y: 440, w: 280, at: 46, anim: "pop", sfx: "pop" }), T("বাবার শোক", { x: CX, y: 740, size: 66, at: 46, anim: "mask" }),
    HALO({ x: 1520, y: 460, r: 300, at: 49 }), E("icon_tunnel", { x: 1520, y: 440, w: 330, at: 49, anim: "pop", sfx: "pop" }), T("মাটির নিচে সুড়ঙ্গ", { x: 1520, y: 740, size: 66, at: 49, anim: "mask" }),
  ] },
  // 4 — truth or legend?
  { id: "s04-question", from: 55, img: I("img08_tunnel_mouth"), kb: "in", scrim: "left", items: [
    HALO({ x: 560, y: 470, r: 380, at: 55 }),
    E("icon_tunnel", { x: 560, y: 450, w: 480, at: 55, anim: "iris", sfx: "pop" }),
    T("আর কেউ ফেরেনি", { x: 560, y: 790, size: 70, at: 58, anim: "mask" }),
    E("big_question", { x: 1330, y: 400, w: 440, at: 61, anim: "stamp", sfx: "chime", glow: true }),
    E("tag_history", { x: 1130, y: 800, w: 400, at: 64, anim: "slideL" }), T("ইতিহাস", { x: 1130, y: 800, size: 64, at: 64, anim: "pop", color: "text" }),
    T("নাকি", { x: 1360, y: 800, size: 50, at: 65, anim: "pop", color: "textDim", w: 120 }),
    E("tag_legend", { x: 1590, y: 800, w: 400, at: 66, anim: "slideR", sfx: "click" }), T("কিংবদন্তি", { x: 1590, y: 800, size: 60, at: 66, anim: "pop", color: "heroLight" }),
  ] },
  // 5 — 1678 + prince
  { id: "s05-1678", from: 68, img: I("img21_map_dhaka"), kb: "down", bright: 0.38, scrim: "center", items: [
    T("রহস্যের দরজায় কড়া", { x: CX, y: 190, size: 80, at: 71, emph: [0] }),
    E("date_plaque_a", { x: 700, y: 520, w: 900, at: 77, anim: "pop", sfx: "chime" }),
    C(1678, { x: 700, y: 520, size: 140, at: 77, dur: 0.9 }),
    E("pin_gold", { x: 1450, y: 500, w: 260, at: 75, anim: "drop", sfx: "pop" }),
    E("nameplate", { x: CX, y: 880, w: 1200, at: 86, anim: "rise", sfx: "chime" }),
    T("যুবরাজ মুহাম্মদ আজম", { x: CX, y: 880, size: 72, at: 86, d: 0.15, anim: "mask" }),
  ] },
  // 6 — card split: fort by the river
  { id: "s06-fort", from: 89, img: I("img15_court"), kb: "left", mode: "card", card: { x: 1370, y: 540, w: 780, h: 760 }, items: [
    E("icon_boat", { x: 520, y: 220, w: 200, at: 89, anim: "pop", sfx: "pop" }),
    T("বুড়িগঙ্গার উত্তর পাড়ে", { x: 520, y: 400, size: 66, w: 760, at: 89, anim: "mask" }),
    T("এক বিশাল দুর্গ-প্রাসাদ", { x: 520, y: 540, size: 54, w: 760, at: 95, color: "textDim" }),
    E("nameplate", { x: 500, y: 780, w: 760, at: 98, anim: "rise", sfx: "chime" }),
    T("ঔরঙ্গাবাদ কেল্লা", { x: 500, y: 780, size: 60, at: 98, d: 0.15, anim: "mask", w: 700 }),
  ] },
  // 7 — royal world (glass cards)
  { id: "s07-bento", from: 102, img: I("img07_diwan"), kb: "out", bright: 0.45, items: [
    T("পরিকল্পনাটা রাজকীয়", { x: CX, y: 150, size: 84, at: 102, emph: [1] }),
    CARD({ x: 330, y: 560, w: 290, h: 430, at: 105 }), E("icon_gate", { x: 330, y: 500, w: 220, at: 105, anim: "pop", sfx: "pop" }), T("প্রাসাদ", { x: 330, y: 700, size: 56, w: 270, at: 105, anim: "pop" }),
    CARD({ x: 645, y: 560, w: 290, h: 430, at: 106 }), E("divider", { x: 645, y: 500, w: 200, at: 106, anim: "drawX" }), T("বাগান", { x: 645, y: 590, size: 72, w: 270, at: 106, anim: "pop" }),
    CARD({ x: 960, y: 560, w: 290, h: 430, at: 107 }), E("icon_mosque", { x: 960, y: 500, w: 230, at: 107, anim: "pop", sfx: "pop" }), T("মসজিদ", { x: 960, y: 700, size: 56, w: 270, at: 107, anim: "pop" }),
    CARD({ x: 1275, y: 560, w: 290, h: 430, at: 108 }), E("icon_scroll", { x: 1275, y: 500, w: 200, at: 108, anim: "pop", sfx: "pop" }), T("দরবার হল", { x: 1275, y: 700, size: 52, w: 270, at: 108, anim: "pop" }),
    CARD({ x: 1590, y: 560, w: 290, h: 430, at: 111 }), E("fountain_icon", { x: 1590, y: 500, w: 200, at: 111, anim: "pop", sfx: "pop" }), T("ফোয়ারা", { x: 1590, y: 700, size: 56, w: 270, at: 111, anim: "pop" }),
    T("একটা পুরো রাজকীয় জগৎ", { x: CX, y: 900, size: 60, at: 115, anim: "mask", color: "textDim" }),
  ] },
  // 8 — half a fort
  { id: "s08-half", from: 123, img: I("img21_map_dhaka"), kb: "in", bright: 0.36, scrim: "center", items: [
    E("half_fort", { x: 760, y: 450, w: 1000, at: 123, d: 0.3, anim: "drawX", glow: true }),
    T("আসল পরিকল্পনার অর্ধেকও নয়", { x: 760, y: 905, size: 72, at: 131, anim: "mask", w: 1400, emph: [3] }),
    HALO({ x: 1560, y: 470, r: 280, at: 137 }),
    E("tag_question", { x: 1560, y: 450, w: 360, at: 137, anim: "stamp", sfx: "chime" }),
    T("বাকি অর্ধেক", { x: 1560, y: 700, size: 64, w: 500, at: 136, anim: "mask" }),
  ] },
  // 9 — down below the city
  { id: "s09-descend", from: 139, img: I("img12_excavation"), kb: "down", scrim: "center", items: [
    T("উত্তর লুকিয়ে আছে", { x: CX, y: 170, size: 74, at: 140 }),
    T("আজকের শহরের", { x: CX, y: 310, size: 96, at: 143 }),
    T("নিচে", { x: CX, y: 470, size: 170, at: 145, anim: "pop", emph: [0], sfx: "thud" }),
    E("arrow_down", { x: CX, y: 810, w: 150, at: 145, d: 0.25, anim: "drawY" }),
  ] },
  // 10 — question 1 + 15 months
  { id: "s10-q1", from: 151, img: I("img02_unfinished_wall"), kb: "out", scrim: "right", items: [
    E("qcard_1", { x: 430, y: 540, w: 620, at: 151, anim: "rise", sfx: "pop" }),
    T("প্রশ্ন ১", { x: 430, y: 410, size: 60, at: 151, d: 0.2, color: "hero", anim: "pop" }),
    T("নির্মাণ কেন\nথেমে গেল?", { x: 430, y: 620, size: 70, w: 480, at: 153, anim: "mask" }),
    T("কাজ শুরুর মাত্র", { x: 1330, y: 330, size: 58, at: 162, color: "textDim" }),
    E("date_plaque_b", { x: 1330, y: 500, w: 780, at: 164, anim: "pop", sfx: "chime" }),
    C(15, { x: 1330, y: 500, size: 130, at: 164, dur: 1.0, suffix: " মাস" }),
    T("মাথায় যুবরাজকে ফিরে যেতে হলো", { x: 1330, y: 720, size: 54, w: 760, at: 168, anim: "mask" }),
  ] },
  // 11 — the call (journey)
  { id: "s11-journey", from: 173, img: [I("img15_court"), I("img01_gate")], cutAt: 187, kb: "left", items: [
    T("ডেকে পাঠালেন", { x: 520, y: 330, size: 76, at: 176, anim: "mask" }),
    E("arrow_curve", { x: 960, y: 520, w: 1100, at: 177, d: 0.2, anim: "drawX", glow: true }),
    T("রাজপুত যুদ্ধ", { x: 1450, y: 700, size: 84, at: 178, anim: "pop", emph: [0], sfx: "pop" }),
    HALO({ x: 1000, y: 820, r: 330, at: 182 }),
    E("x_seal", { x: 460, y: 820, w: 260, at: 184, anim: "stamp", sfx: "click" }),
    T("বাংলায় ফিরলেন না", { x: 1060, y: 820, size: 72, at: 184, anim: "mask", w: 900 }),
    T("অসমাপ্ত স্বপ্ন", { x: CX, y: 160, size: 70, at: 187, anim: "mask", color: "heroLight" }),
  ] },
  // 12 — Shaista Khan 1680
  { id: "s12-shaista", from: 193, img: I("img07_diwan"), kb: "in", scrim: "center", items: [
    T("নতুন সুবাদার", { x: CX, y: 200, size: 66, at: 195, color: "textDim" }),
    E("nameplate", { x: CX, y: 420, w: 1200, at: 196, anim: "rise", sfx: "chime" }),
    T("শায়েস্তা খাঁ", { x: CX, y: 420, size: 88, at: 197, d: 0.1, anim: "mask" }),
    E("date_plaque_b", { x: CX, y: 760, w: 760, at: 201, anim: "pop", sfx: "chime" }),
    C(1680, { x: CX, y: 760, size: 130, at: 201, dur: 0.8 }),
    T("কাজ আবার শুরু", { x: CX, y: 955, size: 54, at: 204, color: "textDim", anim: "mask" }),
  ] },
  // 13 — walls rising, 1684
  { id: "s13-1684", from: 208, img: I("img03_tomb_exterior"), kb: "up", items: [
    T("দেয়াল উঠছিল", { x: 560, y: 250, size: 82, at: 211, anim: "mask" }),
    T("কেল্লা আকার পাচ্ছিল", { x: 740, y: 380, size: 66, at: 213, color: "textDim", anim: "mask", w: 1000 }),
    E("date_plaque_a", { x: 1330, y: 720, w: 900, at: 218, anim: "stamp", sfx: "chime" }),
    C(1684, { x: 1330, y: 720, size: 140, at: 218, dur: 0.7 }),
  ] },
  // 14 — Pari Bibi
  { id: "s14-paribibi", from: 220, img: I("img04_tomb_interior"), kb: "right", scrim: "left", items: [
    HALO({ x: 480, y: 480, r: 360, at: 220 }),
    E("seal", { x: 480, y: 480, w: 520, at: 228, anim: "iris", sfx: "chime", glow: true }),
    E("icon_tomb", { x: 480, y: 480, w: 210, at: 233, anim: "pop" }),
    T("ইরান দুখত", { x: 1320, y: 380, size: 70, at: 223, color: "textDim", anim: "mask" }),
    E("nameplate", { x: 1320, y: 560, w: 1000, at: 228, anim: "rise", sfx: "pop" }),
    T("পরী বিবি", { x: 1320, y: 560, size: 92, at: 228, d: 0.1, anim: "mask", w: 760 }),
    T("এই কেল্লার ভেতরেই", { x: 1320, y: 780, size: 56, at: 231, color: "textDim", anim: "mask" }),
  ] },
  // 15 — grief + belief
  { id: "s15-belief", from: 236, img: I("img03_tomb_exterior"), kb: "out", mode: "card", card: { x: 560, y: 540, w: 880, h: 760 }, items: [
    T("যুবরাজ আজমের বাগদত্তা", { x: 1410, y: 250, size: 56, w: 740, at: 237, anim: "mask" }),
    T("ভেঙে পড়লেন\nশায়েস্তা খাঁ", { x: 1410, y: 450, size: 76, w: 740, at: 244, anim: "mask" }),
    E("tag_legend", { x: 1410, y: 690, w: 480, at: 248, anim: "slideR", sfx: "click" }),
    T("প্রচলিত বিশ্বাস", { x: 1410, y: 690, size: 52, at: 248, d: 0.1, anim: "pop", color: "heroLight", w: 400 }),
    T("অশুভ", { x: 1410, y: 880, size: 110, at: 254, anim: "pop", emph: [0], sfx: "thud" }),
  ] },
  // 16 — construction stopped → marble tomb
  { id: "s16-stop", from: 257, img: I("img04_tomb_interior"), kb: "in", scrim: "center", items: [
    HALO({ x: 600, y: 520, r: 380, at: 258 }),
    E("x_seal", { x: 600, y: 500, w: 400, at: 259, anim: "stamp", sfx: "click", until: 270 }),
    T("নির্মাণ চিরতরে বন্ধ", { x: 600, y: 800, size: 68, w: 800, at: 258, anim: "mask", until: 270 }),
    E("seal", { x: 600, y: 480, w: 500, at: 272, anim: "iris", sfx: "chime", glow: true }),
    E("icon_tomb", { x: 600, y: 480, w: 200, at: 275, anim: "pop" }),
    T("মার্বেল", { x: 1340, y: 380, size: 90, at: 272, anim: "mask" }),
    T("কালো ব্যাসল্ট পাথর", { x: 1340, y: 540, size: 72, at: 274, anim: "mask", w: 700 }),
    T("অসাধারণ সমাধি", { x: 1340, y: 720, size: 76, at: 277, anim: "mask", emph: [1], w: 700 }),
  ] },
  // 17 — breath: statement on parchment
  { id: "s17-statement", from: 280, mode: "parch", items: [
    T("আজও কেল্লার সবচেয়ে সুন্দর ভবন", { x: CX, y: 340, size: 60, at: 280, color: "inkAccent", anim: "mask", shadow: false }),
    T("শোকের ওপর দাঁড়িয়ে থাকা সৌন্দর্য", { x: CX, y: 640, size: 100, w: 1500, at: 286, color: "ink", shadow: false, emph: [] }),
  ] },
  // 18 — timeline recap
  { id: "s18-timeline", from: 291, img: I("img19_sunset"), kb: "in", bright: 0.5, items: [
    TL({ x: CX, y: 560, w: 1400, at: 291, nodes: [
      { label: "১৬৭৮", sub: "গড়তে শুরু", at: 291 },
      { label: "১৬৮০", sub: "কাজ আবার শুরু", at: 291, d: 0.15 },
      { label: "১৬৮৪", sub: "পরী বিবি", at: 291, d: 0.3 },
      { label: "১৬৮৮", sub: "বাংলা ছেড়ে গেলেন", at: 292 },
    ] }),
    T("কেল্লা রয়ে গেল", { x: CX, y: 860, size: 66, at: 299, color: "textDim" }),
    T("অসমাপ্ত", { x: CX, y: 970, size: 80, at: 303, anim: "pop", emph: [0], sfx: "thud" }),
  ] },
  // 19 — who was Pari Bibi?
  { id: "s19-who", from: 304, img: I("img04_tomb_interior"), kb: "left", scrim: "right", items: [
    E("big_question", { x: 480, y: 500, w: 470, at: 304, anim: "stamp", sfx: "chime", glow: true }),
    T("পরী বিবি", { x: 1300, y: 400, size: 120, at: 310, emph: [] }),
    T("আসলে কে ছিলেন?", { x: 1300, y: 600, size: 84, at: 312, anim: "mask", w: 900, color: "heroLight" }),
  ] },
  // 20 — two versions (versus)
  { id: "s20-versus", from: 315, img: I("img07_diwan"), kb: "in", bright: 0.4, items: [
    E("vs_panel", { x: CX, y: 520, w: 1740, at: 315, anim: "zoom", sfx: "pop" }),
    T("মত ১", { x: 520, y: 360, size: 54, at: 316, color: "textDim", anim: "pop" }),
    T("শায়েস্তা খাঁর\nআদরের মেয়ে", { x: 520, y: 520, size: 62, w: 600, at: 318, anim: "mask" }),
    T("মত ২", { x: 1400, y: 360, size: 54, at: 326, color: "textDim", anim: "pop", sfx: "pop" }),
    T("আহোম রাজার মেয়ে", { x: 1400, y: 470, size: 62, w: 620, at: 331, anim: "mask" }),
    C(9, { x: 1400, y: 630, size: 90, at: 338, dur: 0.7, suffix: " বছর", color: "hero" }),
    T("যুদ্ধের শর্ত", { x: 1400, y: 735, size: 52, w: 620, at: 341, anim: "mask", color: "textDim" }),
  ] },
  // 21 — fork
  { id: "s21-fork", from: 349, img: I("img03_tomb_exterior"), kb: "out", bright: 0.5, items: [
    T("যুবরাজ আজমের সঙ্গে বিয়ে ঠিক", { x: 640, y: 240, size: 62, w: 1000, at: 352, anim: "mask" }),
    E("fork_arrow", { x: 760, y: 560, w: 1100, at: 355, anim: "drawX", glow: true }),
    T("শায়েস্তা খাঁর কন্যা", { x: 1560, y: 310, size: 66, w: 560, at: 363, anim: "mask", emph: [] }),
    T("আহোম রাজকন্যা", { x: 1560, y: 810, size: 66, w: 560, at: 367, anim: "mask", emph: [1] }),
    T("এক শিশু", { x: 1560, y: 930, size: 50, w: 560, at: 373, anim: "pop", color: "textDim" }),
  ] },
  // 22 — two stories, one tomb
  { id: "s22-lines", from: 375, img: I("img04_tomb_interior"), kb: "in", scrim: "center", items: [
    T("দুটি গল্প", { x: CX, y: 250, size: 104, at: 375, anim: "mask" }),
    T("একেবারে আলাদা", { x: CX, y: 400, size: 80, at: 377, anim: "mask", color: "textDim" }),
    HALO({ x: CX, y: 650, r: 260, at: 379 }),
    E("icon_tomb", { x: CX, y: 650, w: 260, at: 380, anim: "pop", sfx: "pop" }),
    T("সমাধি একটাই", { x: CX, y: 880, size: 92, at: 380, anim: "mask", emph: [1] }),
    E("big_question", { x: 1560, y: 560, w: 260, at: 383, anim: "stamp", sfx: "chime", op: 0.9 }),
  ] },
  // 23 — mystery seal
  { id: "s23-mystery", from: 390, img: I("img03_tomb_exterior"), kb: "right", scrim: "center", items: [
    T("ইতিহাসের পাতায়", { x: CX, y: 190, size: 66, at: 390, color: "textDim" }),
    E("seal", { x: CX, y: 540, w: 640, at: 396, anim: "iris", sfx: "chime", glow: true }),
    T("রহস্য", { x: CX, y: 540, size: 120, at: 397, anim: "pop", emph: [0] }),
    T("ঠিক যেমন তাঁর কেল্লা", { x: CX, y: 930, size: 64, at: 399, anim: "mask", color: "heroLight" }),
  ] },
  // 24 — question 2
  { id: "s24-q2", from: 406, img: I("img09_tunnel_dark"), kb: "in", scrim: "right", items: [
    E("qcard_3", { x: 440, y: 540, w: 620, at: 406, anim: "rise", sfx: "pop" }),
    T("প্রশ্ন ২", { x: 440, y: 410, size: 60, at: 406, d: 0.2, color: "hero", anim: "pop" }),
    T("সুড়ঙ্গ\nকোথায় যায়?", { x: 440, y: 620, size: 70, w: 480, at: 408, anim: "mask" }),
    E("tunnel_arch", { x: 1330, y: 500, w: 640, at: 412, anim: "iris", sfx: "pop" }),
    T("গোপন সুড়ঙ্গ", { x: 1330, y: 880, size: 70, at: 414, anim: "mask" }),
    E("grille", { x: 1330, y: 500, w: 420, at: 420, anim: "drawY", sfx: "click" }),
  ] },
  // 25 — hub & spoke: two tunnels
  { id: "s25-hub", from: 422, img: [I("img11_zinzira"), I("img14_maze_passage")], cutAt: 433, kb: "in", bright: 0.45, items: [
    HALO({ x: 420, y: 540, r: 300, at: 424 }),
    E("icon_tunnel", { x: 420, y: 520, w: 340, at: 424, anim: "pop", sfx: "pop" }),
    T("দুইটা সুড়ঙ্গ", { x: 420, y: 800, size: 64, at: 424, anim: "mask" }),
    E("dashed_path", { x: 940, y: 330, w: 760, at: 427, anim: "drawX", rot: -8 }),
    E("pin_gold", { x: 1450, y: 300, w: 170, at: 429, anim: "drop", sfx: "pop" }),
    T("জিনজিরা দুর্গ", { x: 1450, y: 460, size: 62, at: 429, w: 520, anim: "mask" }),
    E("dashed_path", { x: 940, y: 740, w: 760, at: 433, anim: "drawX", rot: 8 }),
    E("maze", { x: 1450, y: 760, w: 250, at: 436, anim: "iris", sfx: "pop" }),
    T("গোলকধাঁধা", { x: 1450, y: 960, size: 60, at: 436, w: 480, anim: "mask" }),
  ] },
  // 26 — 1857 legend
  { id: "s26-1857", from: 444, img: I("img16_1857"), kb: "left", items: [
    E("tag_legend", { x: 560, y: 220, w: 520, at: 447, anim: "slideL", sfx: "click" }),
    T("কিংবদন্তি", { x: 560, y: 220, size: 76, at: 447, d: 0.1, anim: "pop", color: "heroLight" }),
    E("date_plaque_a", { x: 960, y: 560, w: 900, at: 451, anim: "stamp", sfx: "chime" }),
    C(1857, { x: 960, y: 560, size: 140, at: 451, dur: 0.8 }),
    T("সিপাহি বিদ্রোহের সময়", { x: 960, y: 810, size: 68, at: 453, anim: "mask", w: 1200 }),
    T("আর ফেরেনি", { x: 960, y: 940, size: 64, at: 462, anim: "pop", emph: [1] }),
  ] },
  // 27 — they never returned (tally)
  { id: "s27-tally", from: 464, img: I("img08_tunnel_mouth"), kb: "out", scrim: "left", items: [
    T("ব্রিটিশ সৈন্যরাও", { x: 560, y: 300, size: 76, at: 467, anim: "mask", w: 800 }),
    E("x_seal", { x: 1000, y: 300, w: 170, at: 469, anim: "stamp", sfx: "click" }),
    T("হাতি আর কুকুর", { x: 560, y: 560, size: 76, at: 477, anim: "mask", w: 800 }),
    E("x_seal", { x: 1000, y: 560, w: 170, at: 481, anim: "stamp", sfx: "click" }),
    E("grille", { x: 1520, y: 540, w: 480, at: 486, anim: "drawY", sfx: "thud" }),
    T("চিরতরে বন্ধ", { x: 1520, y: 860, size: 64, at: 486, anim: "mask", w: 520 }),
  ] },
  // 28 — verdict
  { id: "s28-verdict", from: 488, img: I("img09_tunnel_dark"), kb: "left", scrim: "center", items: [
    E("tag_question", { x: 520, y: 380, w: 340, at: 488, anim: "stamp", sfx: "chime", until: 497 }),
    T("সত্যি? নাকি শুধুই গল্প?", { x: 520, y: 720, size: 66, w: 760, at: 489, anim: "mask", until: 497 }),
    E("checkmark_seal", { x: 520, y: 400, w: 400, at: 499, anim: "stamp", sfx: "click", glow: true }),
    T("সুড়ঙ্গ আছে", { x: 1330, y: 400, size: 100, at: 497, anim: "mask" }),
    T("প্রমাণিত", { x: 1330, y: 580, size: 110, at: 502, anim: "pop", emph: [0], sfx: "chime" }),
  ] },
  // 29 — the maze (spotlight)
  { id: "s29-maze", from: 503, img: I("img14_maze_passage"), kb: "in", bright: 0.4, items: [
    SPOT("maze", { x: 520, y: 540, w: 620, at: 503 }),
    T("কোথায় গিয়ে শেষ হয়?", { x: 1330, y: 260, size: 68, w: 800, at: 505, anim: "mask" }),
    T("ঢোকার পথ বন্ধ", { x: 1330, y: 520, size: 80, w: 800, at: 515, anim: "mask", emph: [2] }),
    E("grille", { x: 1330, y: 800, w: 260, at: 517, anim: "drawY", sfx: "click" }),
    T("ওপারে কী আছে?", { x: 1330, y: 960, size: 56, w: 800, at: 522, anim: "mask", color: "textDim" }),
  ] },
  // 30 — the unknown keeps the story alive
  { id: "s30-statement", from: 529, img: I("img09_tunnel_dark"), kb: "out", bright: 0.4, scrim: "center", items: [
    T("সেই অজানাই", { x: CX, y: 400, size: 120, at: 530, emph: [1] }),
    E("divider", { x: CX, y: 560, w: 700, at: 532, anim: "drawX" }),
    T("গল্পকে বাঁচিয়ে রেখেছে", { x: CX, y: 700, size: 90, at: 533, anim: "mask", w: 1500 }),
    HALO({ x: CX, y: 880, r: 140, at: 538 }),
    E("icon_lantern", { x: CX, y: 880, w: 110, at: 538, anim: "pop", sfx: "pop" }),
  ] },
  // 31 — from legend to proof
  { id: "s31-shift", from: 549, img: I("img12_excavation"), kb: "right", items: [
    E("tag_legend", { x: 500, y: 330, w: 520, at: 549, anim: "slideL", sfx: "click", op: 0.8 }), T("কিংবদন্তি", { x: 500, y: 330, size: 70, at: 549, d: 0.1, anim: "pop", color: "textDim" }),
    E("arrow_right", { x: 960, y: 330, w: 340, at: 551, anim: "drawX" }),
    E("tag_history", { x: 1420, y: 330, w: 520, at: 553, anim: "slideR", sfx: "click" }), T("প্রমাণ", { x: 1420, y: 330, size: 84, at: 553, d: 0.1, anim: "pop", color: "heroLight" }),
    HALO({ x: CX, y: 750, r: 330, at: 556 }),
    E("icon_map", { x: 640, y: 740, w: 260, at: 556, anim: "pop", sfx: "pop" }),
    T("সাম্প্রতিক খনন", { x: 1250, y: 740, size: 86, w: 900, at: 556, anim: "mask", emph: [1] }),
  ] },
  // 32 — cross-section: wall under the road
  { id: "s32-section", from: 564, img: I("img10_buriganga"), kb: "up", bright: 0.45, items: [
    T("কেল্লা এলাকার পূর্ব দিকে", { x: CX, y: 150, size: 60, at: 565, color: "textDim", anim: "mask" }),
    T("শায়েস্তা খাঁ রোডের নিচে", { x: CX, y: 340, size: 96, at: 569, anim: "mask", w: 1600, emph: [] }),
    E("dashed_path", { x: CX, y: 520, w: 1500, at: 573, anim: "drawX", glow: true }),
    T("মূল দেয়ালের ধারাবাহিকতা", { x: CX, y: 680, size: 72, at: 574, anim: "mask", emph: [2] }),
    E("half_fort", { x: 1500, y: 850, w: 420, at: 577, anim: "pop", sfx: "chime", op: 0.9 }),
    T("অর্ধেকটাই আজকের কেল্লা", { x: 700, y: 900, size: 62, w: 1100, at: 581, anim: "mask", color: "heroLight" }),
  ] },
  // 33 — other half: unfinished or buried
  { id: "s33-otherhalf", from: 584, img: I("img10_buriganga"), kb: "in", bright: 0.45, items: [
    E("half_fort", { x: 620, y: 500, w: 900, at: 584, anim: "zoom", glow: true }),
    T("প্রশাসনিক ভবন", { x: 1500, y: 290, size: 66, w: 600, at: 586, anim: "mask" }),
    T("আবাসিক এলাকা", { x: 1500, y: 420, size: 66, w: 600, at: 589, anim: "mask" }),
    T("অসমাপ্ত ছিল", { x: 1500, y: 640, size: 66, w: 600, at: 592, anim: "pop", color: "textDim" }),
    T("চাপা পড়ে গেছে", { x: 1500, y: 790, size: 76, w: 640, at: 595, anim: "mask", emph: [1] }),
  ] },
  // 34 — 26 structures
  { id: "s34-counter", from: 601, img: I("img13_water_channel"), kb: "left", bright: 0.5, items: [
    E("counter_plaque", { x: 560, y: 470, w: 760, at: 601, anim: "pop", sfx: "chime" }),
    C(26, { x: 560, y: 470, size: 112, at: 603, dur: 1.0, suffix: "টি" }),
    T("অতিরিক্ত কাঠামো", { x: 560, y: 760, size: 66, at: 604, anim: "mask", w: 800 }),
    CARD({ x: 1380, y: 350, w: 640, h: 130, at: 608 }), T("পানি সরবরাহ", { x: 1380, y: 350, size: 58, at: 608, anim: "pop", w: 600 }),
    CARD({ x: 1380, y: 510, w: 640, h: 130, at: 611 }), T("নর্দমার ব্যবস্থা", { x: 1380, y: 510, size: 58, at: 611, anim: "pop", w: 600 }),
    CARD({ x: 1380, y: 670, w: 640, h: 130, at: 614 }), T("ছাদের বাগান", { x: 1380, y: 670, size: 58, at: 614, anim: "pop", w: 600 }),
    CARD({ x: 1380, y: 830, w: 640, h: 130, at: 616 }), T("ফোয়ারা", { x: 1380, y: 830, size: 58, at: 616, anim: "pop", w: 600, sfx: "pop" }),
  ] },
  // 35 — a city beneath the road
  { id: "s35-descend", from: 617, img: I("img06_hammam"), kb: "down", scrim: "center", items: [
    T("যে রাস্তা দিয়ে হেঁটে যাই", { x: CX, y: 170, size: 66, at: 618, w: 1500 }),
    E("divider", { x: CX, y: 290, w: 900, at: 622, anim: "drawX" }),
    T("তার নিচে", { x: CX, y: 420, size: 110, at: 623, anim: "pop", emph: [1] }),
    E("arrow_down", { x: CX, y: 690, w: 120, at: 624, anim: "drawY" }),
    T("একটা পুরো শহরের গল্প", { x: CX, y: 930, size: 84, at: 627, anim: "mask", w: 1500 }),
  ] },
  // 36 — 22 Nov 1857
  { id: "s36-nov1857", from: 637, img: I("img16_1857"), kb: "in", bright: 0.5, items: [
    E("date_plaque_a", { x: 960, y: 330, w: 1000, at: 637, anim: "stamp", sfx: "chime" }),
    T("২২ নভেম্বর ১৮৫৭", { x: 960, y: 330, size: 92, at: 637, d: 0.1, w: 860, anim: "pop", color: "hero" }),
    T("তিয়াত্তর নম্বর দেশীয় পদাতিক বাহিনী", { x: CX, y: 640, size: 70, w: 1500, at: 640, anim: "mask" }),
    T("কেল্লায় আশ্রয়", { x: CX, y: 860, size: 96, at: 646, anim: "pop", emph: [1], sfx: "pop" }),
  ] },
  // 37 — suppression → British control (flow)
  { id: "s37-flow", from: 650, img: I("img16_1857"), kb: "out", bright: 0.45, items: [
    E("nameplate", { x: 440, y: 480, w: 700, at: 650, anim: "slideL", sfx: "pop" }),
    T("বিদ্রোহ দমন", { x: 440, y: 480, size: 62, at: 651, d: 0.1, anim: "mask", w: 600 }),
    E("arrow_right", { x: 960, y: 480, w: 260, at: 655, anim: "drawX" }),
    E("nameplate", { x: 1480, y: 480, w: 700, at: 658, anim: "slideR", sfx: "pop" }),
    T("ব্রিটিশ সামরিক\nনিয়ন্ত্রণ", { x: 1480, y: 480, size: 44, at: 659, d: 0.1, anim: "mask", w: 600 }),
    T("কঠোরভাবে", { x: 440, y: 700, size: 54, at: 654, anim: "pop", color: "textDim" }),
  ] },
  // 38 — renamed Lalbagh (before / after)
  { id: "s38-rename", from: 662, img: I("img01_gate"), kb: "left", bright: 0.5, items: [
    E("date_plaque_b", { x: CX, y: 190, w: 620, at: 662, anim: "pop", sfx: "chime" }),
    C(1844, { x: CX, y: 190, size: 96, at: 662, dur: 0.7 }),
    T("ঔরঙ্গাবাদ", { x: 520, y: 520, size: 100, at: 664, anim: "mask", color: "textDim" }),
    E("arrow_right", { x: 960, y: 530, w: 260, at: 666, anim: "drawX" }),
    E("ribbon_gold", { x: 1380, y: 520, w: 800, at: 668, anim: "slideR", sfx: "chime" }),
    T("লালবাগ", { x: 1380, y: 520, size: 100, at: 668, d: 0.1, anim: "pop", emph: [0] }),
    T("লাল বাগান", { x: 1380, y: 700, size: 64, at: 669, anim: "mask", color: "heroLight" }),
  ] },
  // 39 — today (glass cards with place photos)
  { id: "s39-today", from: 672, img: I("img17_museum"), kb: "in", bright: 0.45, items: [
    T("সময় বদলেছে", { x: CX, y: 150, size: 88, at: 672, emph: [1] }),
    CARD({ x: 480, y: 540, w: 480, h: 520, at: 676 }), E("icon_gate", { x: 480, y: 470, w: 230, at: 676, anim: "pop", sfx: "pop" }), T("দিওয়ান-ই-আমে\nজাদুঘর", { x: 480, y: 710, size: 52, w: 440, at: 676, anim: "pop" }),
    CARD({ x: 960, y: 540, w: 480, h: 520, at: 678 }), E("icon_mosque", { x: 960, y: 470, w: 250, at: 678, anim: "pop", sfx: "pop" }), T("মসজিদে নামাজ", { x: 960, y: 710, size: 56, w: 440, at: 678, anim: "pop" }),
    CARD({ x: 1440, y: 540, w: 480, h: 520, at: 682 }), E("fountain_icon", { x: 1440, y: 470, w: 220, at: 682, anim: "pop", sfx: "pop" }), T("বাগানে হাজারো\nমানুষ", { x: 1440, y: 710, size: 52, w: 440, at: 682, anim: "pop" }),
  ] },
  // 40 — still unfinished
  { id: "s40-still", from: 688, img: I("img02_unfinished_wall"), kb: "in", bright: 0.5, scrim: "center", items: [
    T("এত কিছুর পরেও", { x: CX, y: 330, size: 74, at: 689, color: "textDim" }),
    T("আজও অসমাপ্তই", { x: CX, y: 540, size: 130, at: 693, emph: [1], sfx: "thud" }),
    E("divider", { x: CX, y: 720, w: 700, at: 695, anim: "drawX" }),
  ] },
  // 41 — memorial (frame)
  { id: "s41-memorial", from: 697, img: I("img19_sunset"), kb: "out", scrim: "center", items: [
    E("frame_ornate", { x: CX, y: CY, w: 1840, at: 697, anim: "zoom", sfx: "whoosh" }),
    T("লালবাগ কেল্লা আসলে", { x: CX, y: 340, size: 70, at: 697, color: "textDim" }),
    T("এক অসমাপ্ত স্বপ্নের\nস্মৃতিস্তম্ভ", { x: CX, y: 580, size: 112, at: 700, emph: [2], sfx: "chime" }),
  ] },
  // 42 — recap trio
  { id: "s42-recap", from: 705, img: I("img04_tomb_interior"), kb: "right", scrim: "center", items: [
    CARD({ x: 400, y: 540, w: 480, h: 640, at: 705 }), HALO({ x: 400, y: 440, r: 220, at: 705 }), E("icon_scroll", { x: 400, y: 420, w: 220, at: 705, anim: "pop", sfx: "pop" }), T("যুবরাজের\nস্বপ্ন", { x: 400, y: 700, size: 70, w: 440, at: 706, anim: "mask" }),
    CARD({ x: CX, y: 540, w: 480, h: 640, at: 708 }), HALO({ x: CX, y: 440, r: 220, at: 708 }), E("icon_lantern", { x: CX, y: 420, w: 190, at: 708, anim: "pop", sfx: "pop" }), T("বাবার\nশোক", { x: CX, y: 700, size: 70, w: 440, at: 709, anim: "mask" }),
    CARD({ x: 1520, y: 540, w: 480, h: 640, at: 711 }), HALO({ x: 1520, y: 440, r: 220, at: 711 }), E("icon_tomb", { x: 1520, y: 420, w: 230, at: 711, anim: "pop", sfx: "pop" }), T("অকালমৃত্যু", { x: 1520, y: 700, size: 66, w: 440, at: 712, anim: "mask" }),
  ] },
  // 43 — 340 years, still unfinished
  { id: "s43-identity", from: 714, img: I("img19_sunset"), kb: "in", bright: 0.45, scrim: "center", items: [
    C(340, { x: CX, y: 270, size: 140, at: 714, dur: 1.2, suffix: " বছর" }),
    T("দেয়ালগুলো সেই গল্পটাই বলে যাচ্ছে", { x: CX, y: 470, size: 62, at: 718, w: 1500, anim: "mask" }),
    E("divider", { x: CX, y: 620, w: 760, at: 724, anim: "drawX" }),
    T("কেল্লাটা শেষ হয়নি", { x: CX, y: 780, size: 100, at: 724, anim: "mask", w: 1500 }),
    T("সেটাই আসল পরিচয়", { x: CX, y: 940, size: 66, at: 728, anim: "mask", emph: [1], w: 1200 }),
  ] },
  // 44 — comment CTA
  { id: "s44-comment", from: 732, img: I("img08_tunnel_mouth"), kb: "in", bright: 0.5, scrim: "right", items: [
    E("comment_bubble", { x: 480, y: 480, w: 700, at: 732, anim: "pop", sfx: "pop" }),
    T("তুমি কি লালবাগ কেল্লায় গেছো?\nসিল করা সুড়ঙ্গের মুখটা কি\nনিজের চোখে দেখেছো?", { x: 1340, y: 450, size: 56, w: 760, at: 733, anim: "type", per: 8, align: "left" }),
    T("কমেন্টে জানাও!", { x: 1340, y: 800, size: 92, w: 760, at: 745, anim: "pop", emph: [0], sfx: "chime" }),
  ] },
  // 45 — teaser
  { id: "s45-teaser", from: 747, img: I("img20_panam_teaser"), kb: "right", bright: 0.65, items: [
    T("তোমার দেখা গল্পটাই", { x: CX, y: 260, size: 78, at: 747 }),
    T("পরের পর্বের শুরু", { x: CX, y: 400, size: 96, at: 750, emph: [1] }),
    E("ribbon_teal", { x: CX, y: 760, w: 1500, at: 755, anim: "slideL", sfx: "whoosh" }),
    T("পরের পর্ব: পানাম নগর", { x: CX, y: 760, size: 80, at: 757, d: 0.2, anim: "mask", w: 1100 }),
  ] },
  // 46 — end card
  { id: "s46-end", from: 762, img: I("img20_panam_teaser"), mode: "teal", kb: "in", bright: 0.5, items: [
    T("একসময় বাংলার সবচেয়ে ধনী বন্দর", { x: CX, y: 300, size: 76, at: 764, w: 1600, anim: "mask", emph: [] }),
    T("আজ সম্পূর্ণ খালি", { x: CX, y: 460, size: 110, at: 771, anim: "pop", emph: [2] }),
    E("subscribe_btn", { x: CX, y: 760, w: 720, at: 774, d: 0.4, anim: "pop", sfx: "click", glow: true }),
    T("সাবস্ক্রাইব করো", { x: CX, y: 760, size: 64, at: 774, d: 0.55, anim: "pop", w: 560 }),
    T("পরের পর্বে দেখা হবে", { x: CX, y: 930, size: 56, at: 775, d: 0.4, anim: "mask", color: "textDim" }),
  ] },
];
