import React, { useMemo } from "react";
import { AbsoluteFill, Sequence, useVideoConfig } from "remotion";
import { SceneView } from "./engine";
import { Grade, Grain, Vignette, WordCaptions } from "./fx";
import { PreviewAudio } from "./PreviewAudio";
import { SCENES } from "./scenes";
import type { Cue } from "./srt";
import { flags, sec, theme } from "./theme";

export type MainProps = { cues: Cue[] };

/** Scene boundaries come only from SRT cue starts (minus a small lead). */
export const Main: React.FC<MainProps> = ({ cues }) => {
  const { fps, durationInFrames } = useVideoConfig();
  const tl = useMemo(() => {
    if (!cues.length) return [];
    const starts = SCENES.map((d, i) => (i === 0 ? 0 : Math.max(0, Math.round(cues[d.from - 1].start * fps) - sec(theme.time.sceneLead, fps))));
    return SCENES.map((def, i) => ({ def, i, start: starts[i], dur: (i < SCENES.length - 1 ? starts[i + 1] : durationInFrames) - starts[i] }));
  }, [cues, fps, durationInFrames]);
  const T = sec(theme.time.trans, fps);
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      {tl.map((s) => (
        <Sequence key={s.def.id} from={s.start} durationInFrames={Math.min(s.dur + T, durationInFrames - s.start)} name={s.def.id}>
          <SceneView def={s.def} index={s.i} start={s.start} dur={s.dur} cues={cues} />
        </Sequence>
      ))}
      <Grade />
      <Grain />
      <Vignette />
      {flags.WORD_CAPTIONS && <WordCaptions cues={cues} />}
      <PreviewAudio />
    </AbsoluteFill>
  );
};
