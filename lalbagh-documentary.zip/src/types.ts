import type { ColorName, SfxName } from "./theme";
export type Anim = "pop" | "rise" | "zoom" | "drawX" | "drawY" | "iris" | "stamp" | "drop" | "slideL" | "slideR";
type Base = { at: number; d?: number; until?: number; sfx?: SfxName; z?: number };
export type ElItem = Base & { k: "el"; src: string; x: number; y: number; w: number; anim?: Anim; op?: number; rot?: number; glow?: boolean; blend?: "screen" | "normal"; breathe?: boolean };
export type TxItem = Base & { k: "tx"; text: string; x: number; y: number; size?: number; w?: number; color?: ColorName; font?: "display" | "body"; align?: "left" | "center" | "right"; anim?: "words" | "mask" | "pop" | "rise" | "type"; emph?: number[]; per?: number; shadow?: boolean };
export type CtItem = Base & { k: "ct"; to: number; x: number; y: number; size?: number; dur?: number; suffix?: string; color?: ColorName };
export type CardItem = Base & { k: "card"; x: number; y: number; w: number; h: number };
export type HaloItem = Base & { k: "halo"; x: number; y: number; r: number };
export type TlItem = Base & { k: "tl"; x: number; y: number; w: number; nodes: { label: string; sub: string; at: number; d?: number }[] };
export type SpotItem = Base & { k: "spot"; src: string; x: number; y: number; w: number };
export type Item = ElItem | TxItem | CtItem | CardItem | HaloItem | TlItem | SpotItem;
export type KB = "in" | "out" | "left" | "right" | "up" | "down";
export type SceneDef = {
  id: string; from: number; img?: string | [string, string]; cutAt?: number; kb?: KB;
  mode?: "full" | "card" | "parch" | "teal"; card?: { x: number; y: number; w: number; h: number };
  bright?: number; scrim?: "bottom" | "left" | "right" | "center"; items: Item[];
};
