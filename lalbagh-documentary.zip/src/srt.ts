export type Cue = { i: number; start: number; end: number; text: string };
const t = (h: string, m: string, s: string, ms: string) => +h * 3600 + +m * 60 + +s + +ms / 1000;
export const parseSrt = (raw: string): Cue[] =>
  raw.replace(/\r/g, "").replace(/^\uFEFF/, "").trim().split(/\n\n+/).map((b) => {
    const l = b.split("\n");
    const m = l[1].match(/(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)/)!;
    return { i: +l[0], start: t(m[1], m[2], m[3], m[4]), end: t(m[5], m[6], m[7], m[8]), text: l.slice(2).join(" ") };
  });
